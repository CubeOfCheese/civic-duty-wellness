import React from 'react';

function User() {
  return (
    <div className='User'>
      <h1> User Profile Name</h1>
      
      <p1> Community Annoucements</p1>
    </div>
  );
}

export default User;
