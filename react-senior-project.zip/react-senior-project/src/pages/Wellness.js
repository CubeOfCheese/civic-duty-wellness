import React from 'react';

function Wellness() {
  return (
    <div className='Wellness'>
      <h1>Wellness</h1>
    </div>
  );
}

export default Wellness;